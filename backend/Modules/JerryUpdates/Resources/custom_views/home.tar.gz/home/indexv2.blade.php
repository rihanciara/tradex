@extends('layouts.app')
@section('title', __('home.home'))

@section('content')



<div class="dashboard-container">
    <div class="dashboard-header">
        <div class="header-left">
            <h1>Dashboard</h1>
            {{-- <p>Quick access to all your business tools</p> --}}
        </div>
        <div class="digital-clock" id="digitalClock">
            <span class="clock-time" id="clockTime">00:00<span class="am-pm">AM</span></span>
            <span class="clock-date" id="clockDate">Loading...</span>
        </div>
    </div>
    <!-- Expandable Transactions Panel -->
    <div id="transactions-panel" class="transactions-panel">
        {{-- <h3 style="margin-bottom: 20px; color: #333;">Financial Overview</h3> --}}
        <div class="metrics-grid">
            <div class="tw-pb-6 xl:tw-pb-0 ">
                <div class="tw-px-5 tw-pt-3">

                    <div class="sm:tw-flex sm:tw-items-center sm:tw-justify-between sm:tw-gap-12">


                        @if (auth()->user()->can('dashboard.data'))
                        @if ($is_admin)
                        <div class="tw-mt-2 sm:tw-w-1/3 md:tw-w-1/4 ">
                            @if (count($all_locations) > 1)
                            {!! Form::select('dashboard_location', $all_locations, null, [
                            'class' => 'form-control select2',
                            'placeholder' => __('lang_v1.select_location'),
                            'id' => 'dashboard_location',
                            ]) !!}
                            @endif
                        </div>

                        <div class="tw-mt-2 sm:tw-w-1/3 md:tw-w-1/4 tw-text-right">
                            @if ($is_admin)
                            <button type="button" id="dashboard_date_filter"
                                class="tw-inline-flex tw-items-center tw-justify-center tw-w-full tw-gap-1 tw-px-3 tw-py-2 tw-text-sm tw-font-medium tw-text-gray-900 tw-transition-all tw-duration-200 tw-bg-white tw-rounded-lg sm:tw-w-auto hover:tw-bg-primary-50">
                                <svg aria-hidden="true" class="tw-size-5" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path
                                        d="M4 7a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12z" />
                                    <path d="M16 3v4" />
                                    <path d="M8 3v4" />
                                    <path d="M4 11h16" />
                                    <path d="M7 14h.013" />
                                    <path d="M10.01 14h.005" />
                                    <path d="M13.01 14h.005" />
                                    <path d="M16.015 14h.005" />
                                    <path d="M13.015 17h.005" />
                                    <path d="M7.01 17h.005" />
                                    <path d="M10.01 17h.005" />
                                </svg>
                                <span>
                                    {{ __('messages.filter_by_date') }}
                                </span>
                                <svg aria-hidden="true" class="tw-size-4" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path d="M6 9l6 6l6 -6" />
                                </svg>
                            </button>
                            @endif
                        </div>
                        @endif
                        @endif
                    </div>
                    @if (auth()->user()->can('dashboard.data'))
                    @if ($is_admin)
                    <div
                        class="tw-grid tw-grid-cols-1 tw-gap-4 tw-mt-6 sm:tw-grid-cols-2 xl:tw-grid-cols-4 sm:tw-gap-5">

                        <div
                            class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm hover:tw-shadow-md tw-rounded-xl  tw-ring-1 tw-ring-gray-200">
                            <div class="tw-p-4 sm:tw-p-5">
                                <div class="tw-flex tw-items-center tw-gap-4">
                                    <div
                                        class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-rounded-full sm:tw-w-12 sm:tw-h-12 tw-shrink-0 tw-bg-sky-100 tw-text-sky-500">
                                        <svg aria-hidden="true" class="tw-w-6 tw-h-6" xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                            <path d="M6 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
                                            <path d="M17 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
                                            <path d="M17 17h-11v-14h-2" />
                                            <path d="M6 5l14 1l-1 7h-13" />
                                        </svg>
                                    </div>

                                    <div class="tw-flex-1 tw-min-w-0">
                                        <p
                                            class="tw-text-sm tw-font-medium tw-text-gray-500 tw-truncate tw-whitespace-nowrap">
                                            {{ __('home.total_sell') }}
                                        </p>
                                        <p
                                            class="total_sell tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div
                            class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm hover:tw-shadow-md tw-rounded-xl hover:tw--translate-y-0.5 tw-ring-1 tw-ring-gray-200">
                            <div class="tw-p-4 sm:tw-p-5">
                                <div class="tw-flex tw-items-center tw-gap-4">
                                    <div
                                        class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-text-green-500 tw-bg-green-100 tw-rounded-full sm:tw-w-12 sm:tw-h-12 tw-shrink-0">
                                        <svg aria-hidden="true" class="tw-w-6 tw-h-6" xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <path
                                                d="M5 21v-16a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v16l-3 -2l-2 2l-2 -2l-2 2l-2 -2l-3 2">
                                            </path>
                                            <path
                                                d="M14.8 8a2 2 0 0 0 -1.8 -1h-2a2 2 0 1 0 0 4h2a2 2 0 1 1 0 4h-2a2 2 0 0 1 -1.8 -1">
                                            </path>
                                            <path d="M12 6v10"></path>
                                        </svg>
                                    </div>

                                    <div class="tw-flex-1 tw-min-w-0">
                                        <p
                                            class="tw-text-sm tw-font-medium tw-text-gray-500 tw-truncate tw-whitespace-nowrap">
                                            {{ __('lang_v1.net') }} @show_tooltip(__('lang_v1.net_home_tooltip'))
                                        </p>
                                        <p
                                            class="net tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div
                            class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm hover:tw-shadow-md tw-rounded-xl hover:tw--translate-y-0.5 tw-ring-1 tw-ring-gray-200">
                            <div class="tw-p-4 sm:tw-p-5">
                                <div class="tw-flex tw-items-center tw-gap-4">
                                    <div
                                        class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-text-yellow-500 tw-bg-yellow-100 tw-rounded-full sm:tw-w-12 sm:tw-h-12 shrink-0">
                                        <svg aria-hidden="true" class="tw-w-6 tw-h-6" xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                            <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                                            <path
                                                d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z" />
                                            <path d="M9 7l1 0" />
                                            <path d="M9 13l6 0" />
                                            <path d="M13 17l2 0" />
                                        </svg>
                                    </div>

                                    <div class="tw-flex-1 tw-min-w-0">
                                        <p
                                            class="tw-text-sm tw-font-medium tw-text-gray-500 tw-truncate tw-whitespace-nowrap">
                                            {{ __('home.invoice_due') }}
                                        </p>
                                        <p
                                            class="invoice_due tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div
                            class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm hover:tw-shadow-md tw-rounded-xl hover:tw--translate-y-0.5 tw-ring-1 tw-ring-gray-200">
                            <div class="tw-p-4 sm:tw-p-5">
                                <div class="tw-flex tw-items-center tw-gap-4">
                                    <div
                                        class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-text-red-500 tw-bg-red-100 tw-rounded-full sm:tw-w-12 sm:tw-h-12 shrink-0">
                                        <svg aria-hidden="true" class="tw-w-6 tw-h-6" xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                            <path d="M21 7l-18 0" />
                                            <path d="M18 10l3 -3l-3 -3" />
                                            <path d="M6 20l-3 -3l3 -3" />
                                            <path d="M3 17l18 0" />
                                        </svg>
                                    </div>

                                    <div class="tw-flex-1 tw-min-w-0">
                                        <p
                                            class="tw-text-sm tw-font-medium tw-text-gray-500 tw-truncate tw-whitespace-nowrap">
                                            {{ __('lang_v1.total_sell_return') }}
                                            <i class="fa fa-info-circle text-info hover-q no-print" aria-hidden="true"
                                                data-container="body" data-toggle="popover" data-placement="auto bottom"
                                                id="total_srp"
                                                data-value="{{ __('lang_v1.total_sell_return') }}-{{ __('lang_v1.total_sell_return_paid') }}"
                                                data-content="" data-html="true" data-trigger="hover"></i>
                                        </p>
                                        <p
                                            class="total_sell_return tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">
                                        </p>
                                        {{-- <p class="mb-0 text-muted fs-10 mt-5">{{ __('lang_v1.total_sell_return')
                                            }}: <span class="total_sr"></span><br>
                                            {{ __('lang_v1.total_sell_return_paid') }}<span class="total_srp"></span>
                                        </p> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    @endif

                </div>
                @if (auth()->user()->can('dashboard.data'))
                @if ($is_admin)
                <div class="tw-relative">

                    <div class="tw-px-5 tw-isolate">
                        <div
                            class="tw-grid tw-grid-cols-1 tw-gap-4 tw-mt-4 sm:tw-mt-6 sm:tw-grid-cols-2 xl:tw-grid-cols-4 sm:tw-gap-5">
                            <div
                                class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm tw-rounded-xl hover:tw-shadow-md hover:tw--translate-y-0.5 tw-ring-1 tw-ring-gray-200">
                                <div class="tw-p-4 sm:tw-p-5">
                                    <div class="tw-flex tw-items-center tw-gap-4">
                                        <div
                                            class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-rounded-full sm:tw-w-12 sm:tw-h-12 shrink-0 bg-sky-100 tw-text-sky-500">
                                            <svg aria-hidden="true" class="tw-w-6 tw-h-6"
                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="2"
                                                stroke="currentColor" fill="none" stroke-linecap="round"
                                                stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M12 3v12"></path>
                                                <path d="M16 11l-4 4l-4 -4"></path>
                                                <path d="M3 12a9 9 0 0 0 18 0"></path>
                                            </svg>
                                        </div>

                                        <div class="tw-flex-1 tw-min-w-0">
                                            <p
                                                class="tw-text-sm tw-font-medium tw-text-gray-500 tw-truncate tw-whitespace-nowrap">
                                                {{ __('home.total_purchase') }}
                                            </p>
                                            <p
                                                class="total_purchase tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm tw-rounded-xl hover:tw-shadow-md hover:tw--translate-y-0.5 tw-ring-1 tw-ring-gray-200">
                                <div class="tw-p-4 sm:tw-p-5">
                                    <div class="tw-flex tw-items-center tw-gap-4">
                                        <div
                                            class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-text-yellow-500 tw-bg-yellow-100 tw-rounded-full sm:tw-w-12 sm:tw-h-12 shrink-0">
                                            <svg aria-hidden="true" class="tw-w-6 tw-h-6"
                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="2"
                                                stroke="currentColor" fill="none" stroke-linecap="round"
                                                stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                <path d="M12 9v4" />
                                                <path
                                                    d="M10.363 3.591l-8.106 13.534a1.914 1.914 0 0 0 1.636 2.871h16.214a1.914 1.914 0 0 0 1.636 -2.87l-8.106 -13.536a1.914 1.914 0 0 0 -3.274 0z" />
                                                <path d="M12 16h.01" />
                                            </svg>
                                        </div>

                                        <div>
                                            <p class="tw-text-sm tw-font-medium tw-text-gray-500">
                                                {{ __('home.purchase_due') }}
                                            </p>
                                            <p
                                                class="purchase_due tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm tw-rounded-xl hover:tw-shadow-md hover:tw--translate-y-0.5 tw-ring-1 tw-ring-gray-200">
                                <div class="tw-p-4 sm:tw-p-5">
                                    <div class="tw-flex tw-items-center tw-gap-4">
                                        <div
                                            class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-text-red-500 tw-bg-red-100 tw-rounded-full sm:tw-w-12 sm:tw-h-12 shrink-0">
                                            <svg aria-hidden="true" class="tw-w-6 tw-h-6"
                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="2"
                                                stroke="currentColor" fill="none" stroke-linecap="round"
                                                stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                <path
                                                    d="M5 21v-16a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v16l-3 -2l-2 2l-2 -2l-2 2l-2 -2l-3 2" />
                                                <path d="M15 14v-2a2 2 0 0 0 -2 -2h-4l2 -2m0 4l-2 -2" />
                                            </svg>
                                        </div>

                                        <div class="tw-flex-1 tw-min-w-0">
                                            <p
                                                class="tw-text-sm tw-font-medium tw-text-gray-500 tw-truncate tw-whitespace-nowrap">
                                                {{ __('lang_v1.total_purchase_return') }}
                                                <i class="fa fa-info-circle text-info hover-q no-print"
                                                    aria-hidden="true" data-container="body" data-toggle="popover"
                                                    data-placement="auto bottom" id="total_prp"
                                                    data-value="{{ __('lang_v1.total_purchase_return') }}-{{ __('lang_v1.total_purchase_return_paid') }}"
                                                    data-content="" data-html="true" data-trigger="hover"></i>
                                            </p>
                                            <p
                                                class="total_purchase_return tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">
                                            </p>
                                            {{-- <p class="mb-0 text-muted fs-10 mt-5">
                                                {{ __('lang_v1.total_purchase_return') }}: <span
                                                    class="total_pr"></span><br>
                                                {{ __('lang_v1.total_purchase_return_paid') }}<span
                                                    class="total_prp"></span></p> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="tw-transition-all tw-duration-200 tw-bg-white tw-shadow-sm tw-rounded-xl hover:tw-shadow-md hover:tw--translate-y-0.5 tw-ring-1 tw-ring-gray-200">
                                <div class="tw-p-4 sm:tw-p-5">
                                    <div class="tw-flex tw-items-center tw-gap-4">
                                        <div
                                            class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-text-red-500 tw-bg-red-100 tw-rounded-full sm:tw-w-12 sm:tw-h-12 shrink-0">
                                            <svg aria-hidden="true" class="tw-w-6 tw-h-6"
                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="2"
                                                stroke="currentColor" fill="none" stroke-linecap="round"
                                                stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path
                                                    d="M5 21v-16a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v16l-3 -2l-2 2l-2 -2l-2 2l-2 -2l-3 2">
                                                </path>
                                                <path
                                                    d="M14.8 8a2 2 0 0 0 -1.8 -1h-2a2 2 0 1 0 0 4h2a2 2 0 1 1 0 4h-2a2 2 0 0 1 -1.8 -1">
                                                </path>
                                                <path d="M12 6v10"></path>
                                            </svg>
                                        </div>

                                        <div class="tw-flex-1 tw-min-w-0">
                                            <p
                                                class="tw-text-sm tw-font-medium tw-text-gray-500 tw-truncate tw-whitespace-nowrap">
                                                {{ __('lang_v1.expense') }}
                                            </p>
                                            <p
                                                class="total_expense tw-mt-0.5 tw-text-gray-900 tw-text-xl tw-truncate tw-font-semibold tw-tracking-tight tw-font-mono">

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- @if (!empty($widgets['after_sale_purchase_totals']))
                @foreach ($widgets['after_sale_purchase_totals'] as $widget)
                {!! $widget !!}
                @endforeach
                @endif --}}
                @endif
                @endif
            </div>
        </div>
    </div>
    <div class="icon-grid">
        <!-- Transactions with toggle functionality -->
        @if(auth()->user()->can('purchase_n_sell_report.view') || auth()->user()->can('contacts_report.view') ||
        auth()->user()->can('stock_report.view') || auth()->user()->can('tax_report.view') ||
        auth()->user()->can('trending_product_report.view') || auth()->user()->can('sales_representative.view') ||
        auth()->user()->can('register_report.view') || auth()->user()->can('expense_report.view'))
        <a href="#" class="app-icon" id="transactions-toggle">
            <div class="icon-container">
                <span class="emoji">📊</span>
            </div>
            <span class="app-label">Transactions</span>
        </a>
        @endif

        <!-- POS -->
        @if(auth()->user()->can('sell.create') && in_array('pos_sale', $enabled_modules))
        <a href="/pos/create" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🏪</span>
            </div>
            <span class="app-label">POS Sale</span>
        </a>
        @endif

        @if(auth()->user()->can('sell.view') && in_array('pos_sale', $enabled_modules))
        <a href="/pos" class="app-icon">
            <div class="icon-container">
                <span class="emoji">📋</span>
            </div>
            <span class="app-label">List POS</span>
        </a>
        @endif

        <!-- Users -->
        @if(auth()->user()->can('user.view') || auth()->user()->can('user.create') || auth()->user()->can('roles.view'))
        @if(auth()->user()->can('user.view'))
        <a href="/users" class="app-icon">
            <div class="icon-container">
                <span class="emoji">👥</span>
            </div>
            <span class="app-label">Users</span>
        </a>
        @endif

        @if(auth()->user()->can('roles.view'))
        <a href="/roles" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🏷️</span>
            </div>
            <span class="app-label">Roles</span>
        </a>
        @endif
        @endif

        <!-- Contacts -->
        @if(auth()->user()->can('supplier.view') || auth()->user()->can('customer.view') ||
        auth()->user()->can('supplier.view_own') || auth()->user()->can('customer.view_own'))
        @if(auth()->user()->can('supplier.view') || auth()->user()->can('supplier.view_own'))
        <a href="/contacts?type=supplier" class="app-icon">
            <div class="icon-container">
                <span class="emoji">📞</span>
            </div>
            <span class="app-label">Suppliers</span>
        </a>
        @endif

        @if(auth()->user()->can('customer.view') || auth()->user()->can('customer.view_own'))
        <a href="/contacts?type=customer" class="app-icon">
            <div class="icon-container">
                <span class="emoji">👤</span>
            </div>
            <span class="app-label">Customers</span>
        </a>
        @endif
        @endif

        <!-- Products -->
        @if(auth()->user()->can('product.view') || auth()->user()->can('product.create') ||
        auth()->user()->can('brand.view') || auth()->user()->can('unit.view') || auth()->user()->can('category.view') ||
        auth()->user()->can('brand.create') || auth()->user()->can('unit.create') ||
        auth()->user()->can('category.create'))
        @if(auth()->user()->can('product.view'))
        <a href="/products" class="app-icon">
            <div class="icon-container">
                <span class="emoji">📦</span>
            </div>
            <span class="app-label">Products</span>
        </a>
        @endif

        @if(auth()->user()->can('product.create'))
        <a href="/products/create" class="app-icon">
            <div class="icon-container">
                <span class="emoji">➕</span>
            </div>
            <span class="app-label">Add Product</span>
        </a>
        @endif

        @if(auth()->user()->can('product.view'))
        <a href="/labels/show" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🏷️</span>
            </div>
            <span class="app-label">Labels</span>
        </a>
        @endif

        @if(auth()->user()->can('category.view') || auth()->user()->can('category.create'))
        <a href="/taxonomies?type=product" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🗂️</span>
            </div>
            <span class="app-label">Categories</span>
        </a>
        @endif
        @endif

        <!-- Purchases -->
        @if(in_array('purchases', $enabled_modules) && (auth()->user()->can('purchase.view') ||
        auth()->user()->can('purchase.create') || auth()->user()->can('purchase.update')))
        @if(auth()->user()->can('purchase.view') || auth()->user()->can('view_own_purchase'))
        <a href="/purchases" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🛒</span>
            </div>
            <span class="app-label">Purchases</span>
        </a>
        @endif

        @if(auth()->user()->can('purchase.create'))
        <a href="/purchases/create" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🛍️</span>
            </div>
            <span class="app-label">Add Purchase</span>
        </a>
        @endif
        @endif

        <!-- Sales -->
        @if($is_admin || auth()->user()->hasAnyPermission(['sell.view', 'sell.create', 'direct_sell.access',
        'view_own_sell_only', 'view_commission_agent_sell', 'access_shipping', 'access_own_shipping',
        'access_commission_agent_shipping', 'access_sell_return', 'direct_sell.view', 'direct_sell.update',
        'access_own_sell_return']))
        @if($is_admin || auth()->user()->hasAnyPermission(['sell.view', 'sell.create', 'direct_sell.access',
        'direct_sell.view', 'view_own_sell_only', 'view_commission_agent_sell', 'access_shipping',
        'access_own_shipping', 'access_commission_agent_shipping']))
        <a href="/sells" class="app-icon">
            <div class="icon-container">
                <span class="emoji">💰</span>
            </div>
            <span class="app-label">Sales</span>
        </a>
        @endif

        @if(in_array('add_sale', $enabled_modules) && auth()->user()->can('direct_sell.access'))
        <a href="/sells/create" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🛍️</span>
            </div>
            <span class="app-label">Add Sale</span>
        </a>
        @endif
        @endif

        <!-- Stock Management -->
        @if(in_array('stock_transfers', $enabled_modules) && (auth()->user()->can('purchase.view') ||
        auth()->user()->can('purchase.create') || auth()->user()->can('view_own_purchase')))
        @if(auth()->user()->can('purchase.view') || auth()->user()->can('view_own_purchase'))
        <a href="/stock-transfers" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🚚</span>
            </div>
            <span class="app-label">Transfers</span>
        </a>
        @endif
        @endif

        @if(in_array('stock_adjustment', $enabled_modules) && (auth()->user()->can('purchase.view') ||
        auth()->user()->can('purchase.create') || auth()->user()->can('view_own_purchase')))
        @if(auth()->user()->can('purchase.view') || auth()->user()->can('view_own_purchase'))
        <a href="/stock-adjustments" class="app-icon">
            <div class="icon-container">
                <span class="emoji">⚖️</span>
            </div>
            <span class="app-label">Adjustments</span>
        </a>
        @endif
        @endif

        <!-- Expenses -->
        @if(in_array('expenses', $enabled_modules) && (auth()->user()->can('all_expense.access') ||
        auth()->user()->can('view_own_expense')))
        @if(auth()->user()->can('expense.add'))
        <a href="/expenses/create" class="app-icon">
            <div class="icon-container">
                <span class="emoji">💸</span>
            </div>
            <span class="app-label">Add Expense</span>
        </a>
        @endif
        @endif

        <!-- Reports -->
        @if(auth()->user()->can('purchase_n_sell_report.view') || auth()->user()->can('contacts_report.view') ||
        auth()->user()->can('stock_report.view') || auth()->user()->can('tax_report.view') ||
        auth()->user()->can('trending_product_report.view') || auth()->user()->can('sales_representative.view') ||
        auth()->user()->can('register_report.view') || auth()->user()->can('expense_report.view'))
        @if((in_array('purchases', $enabled_modules) || in_array('add_sale', $enabled_modules) || in_array('pos_sale',
        $enabled_modules)) && auth()->user()->can('purchase_n_sell_report.view'))
        <a href="/reports/purchase-sell" class="app-icon">
            <div class="icon-container">
                <span class="emoji">📈</span>
            </div>
            <span class="app-label">Purchase Report</span>
        </a>
        @endif

        @if(auth()->user()->can('stock_report.view'))
        <a href="/reports/stock-report" class="app-icon">
            <div class="icon-container">
                <span class="emoji">📊</span>
            </div>
            <span class="app-label">Stock Report</span>
        </a>
        @endif
        @endif

        <!-- Settings -->
        @if(auth()->user()->can('business_settings.access') || auth()->user()->can('barcode_settings.access') ||
        auth()->user()->can('invoice_settings.access') || auth()->user()->can('tax_rate.view') ||
        auth()->user()->can('tax_rate.create') || auth()->user()->can('access_package_subscriptions'))
        @if(auth()->user()->can('business_settings.access'))
        <a href="/business/settings" class="app-icon">
            <div class="icon-container">
                <span class="emoji">⚙️</span>
                {{-- <span class="notification-badge">1</span> --}}
            </div>
            <span class="app-label">Settings</span>
        </a>
        @endif

        @if(auth()->user()->can('invoice_settings.access'))
        <a href="/invoice-schemes" class="app-icon">
            <div class="icon-container">
                <span class="emoji">🧾</span>
            </div>
            <span class="app-label">Invoice Settings</span>
        </a>
        @endif
        @endif
    </div>


</div>



@endsection

@section('css')
<style>
    .select2-container {
        width: 100% !important;
    }
</style>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background: url('img/background2.png') no-repeat center center fixed;
        background-size: cover;
        margin: 0;
        padding: 0;
        min-height: 100vh;
        height: 100vh;
        overflow-x: hidden;
    }

    .dashboard-container {
        width: 100%;
        height: 100vh;
        background: url('img/background2.png') no-repeat center center fixed;
        background-size: cover;
        background-attachment: fixed;
        padding: 30px;
        box-sizing: border-box;
        overflow-y: auto;
    }

    .dashboard-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 40px;
    }

    .dashboard-header h1 {
        color: #ffffff;
        font-size: 2.5rem;
        font-weight: 300;
        margin: 0;
    }

    .dashboard-header p {
        color: #666;
        font-size: 1.1rem;
        margin: 5px 0 0 0;
    }

    .header-left {
        flex: 1;
    }

    /* Digital Clock Styles */
    .digital-clock {
        background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
        border: 3px solid #3498db;
        border-radius: 12px;
        padding: 12px 20px;
        font-family: 'Courier New', monospace;
        font-size: 1.8rem;
        font-weight: bold;
        color: #ecf0f1;
        text-align: center;
        min-width: 200px;
        box-shadow:
            0 4px 12px rgba(0, 0, 0, 0.3),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
        position: relative;
        overflow: hidden;
    }

    .digital-clock::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #3498db, #e74c3c, #3498db);
        animation: pulse 2s ease-in-out infinite;
    }

    .clock-time {
        display: block;
        font-size: 1.8rem;
        letter-spacing: 2px;
        text-shadow: 0 0 10px rgba(52, 152, 219, 0.5);
    }

    .clock-date {
        display: block;
        font-size: 0.9rem;
        opacity: 0.8;
        margin-top: 4px;
        letter-spacing: 1px;
    }

    .am-pm {
        color: #e74c3c;
        font-size: 1.2rem;
        margin-left: 8px;
    }

    @keyframes pulse {

        0%,
        100% {
            opacity: 1;
        }

        50% {
            opacity: 0.5;
        }
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .dashboard-header {
            flex-direction: column;
            text-align: center;
            gap: 20px;
        }

        .digital-clock {
            font-size: 1.4rem;
            min-width: auto;
            padding: 10px 16px;
        }

        .clock-time {
            font-size: 1.4rem;
        }
    }

    /* Android-style icon grid */
    .icon-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 25px;
        margin-bottom: 40px;
    }

    /* Android app icon style */
    .app-icon {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-decoration: none;
        padding: 15px;
        border-radius: 15px;
        transition: all 0.3s ease;
        position: relative;
    }

    .app-icon:hover {
        background: rgba(0, 0, 0, 0.05);
        transform: translateY(-5px);
    }

    .icon-container {
        width: 64px;
        height: 64px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 8px;
        position: relative;
        transition: all 0.3s ease;
    }

    .app-icon:hover .icon-container {
        transform: scale(1.2);
    }

    .icon-container .emoji {
        font-size: 48px;
        line-height: 1;
        filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
        transition: all 0.3s ease;
    }

    .app-icon:hover .icon-container .emoji {
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.15));
    }

    .app-label {
        font-size: 16px;
        color: #ffffff;
        text-align: center;
        font-weight: 500;
        line-height: 1.2;
        max-width: 80px;
        overflow: hidden;
        text-overflow: ellipsis;
        /* white-space: nowrap; */
    }

    /* Notification badge */
    .notification-badge {
        position: absolute;
        top: -5px;
        right: -5px;
        background: #ff4444;
        color: white;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        font-size: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        border: 2px solid white;
    }

    /* Responsive design */
    @media (max-width: 768px) {
        .icon-grid {
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .icon-container {
            width: 56px;
            height: 56px;
        }

        .icon-container i {
            font-size: 24px;
        }

        .app-label {
            font-size: 11px;
        }
    }

    @media (max-width: 480px) {
        .icon-grid {
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .dashboard-container {
            padding: 20px;
        }
    }

    /* Special styling for transactions panel (hidden by default) */
    .transactions-panel {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 15px;
        padding: 20px;
        margin-top: 20px;
        display: none;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .transactions-panel.active {
        display: block;
        animation: slideDown 0.3s ease;
    }

    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .metrics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 20px;
    }

    .metric-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    .metric-value {
        font-size: 24px;
        font-weight: bold;
        color: #333;
        margin-bottom: 5px;
    }

    .metric-label {
        font-size: 12px;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
</style>
@endsection

@section('javascript')

<script src="{{ asset('js/home.js?v=' . $asset_v) }}"></script>

<script>
    // Digital Clock Functionality
    function updateClock() {
        const now = new Date();
        
        // Format time
        let hours = now.getHours();
        let minutes = now.getMinutes();
        let seconds = now.getSeconds();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        
        // Convert to 12-hour format
        hours = hours % 12;
        hours = hours ? hours : 12; // hour '0' should be '12'
        
        // Add leading zeros
        hours = hours.toString().padStart(2, '0');
        minutes = minutes.toString().padStart(2, '0');
        seconds = seconds.toString().padStart(2, '0');
        
        // Format date
        const options = { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        };
        const dateString = now.toLocaleDateString('en-US', options);
        
        // Update display
        document.getElementById('clockTime').innerHTML = 
            `${hours}:${minutes}:${seconds}<span class="am-pm">${ampm}</span>`;
        document.getElementById('clockDate').textContent = dateString;
    }
    
    // Dashboard functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Start clock immediately and update every second
        updateClock();
        setInterval(updateClock, 1000);
        
        // Transactions panel functionality
        const transactionsToggle = document.getElementById('transactions-toggle');
        const transactionsPanel = document.getElementById('transactions-panel');
        
        if (transactionsToggle) {
            transactionsToggle.addEventListener('click', function(e) {
                e.preventDefault();
                transactionsPanel.classList.toggle('active');
            });
            
            // Close panel when clicking outside (but not on dropdowns, modals, or other UI elements)
            document.addEventListener('click', function(e) {
                // Don't close if clicking on the toggle button or panel itself
                if (transactionsToggle.contains(e.target) || transactionsPanel.contains(e.target)) {
                    return;
                }
                
                // Don't close if clicking on various UI elements that might appear outside the panel
                if (e.target.closest('select') || 
                    e.target.closest('.dropdown') || 
                    e.target.closest('.modal') ||
                    e.target.closest('[data-bs-toggle]') ||
                    e.target.closest('.daterangepicker') ||
                    e.target.closest('.datepicker') ||
                    e.target.closest('.calendar') ||
                    e.target.closest('.picker') ||
                    e.target.closest('.flatpickr-calendar') ||
                    e.target.closest('.ui-datepicker') ||
                    e.target.closest('.bootstrap-select') ||
                    e.target.closest('.select2-container') ||
                    e.target.closest('.choices') ||
                    e.target.tagName === 'OPTION' ||
                    e.target.classList.contains('daterangepicker') ||
                    e.target.classList.contains('datepicker') ||
                    document.querySelector('.daterangepicker')?.contains(e.target) ||
                    document.querySelector('.datepicker')?.contains(e.target)) {
                    return;
                }
                
                transactionsPanel.classList.remove('active');
            });
        }
    });
</script>
@endsection
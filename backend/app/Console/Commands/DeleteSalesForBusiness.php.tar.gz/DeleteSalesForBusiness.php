<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Transaction;
use App\Utils\TransactionUtil;

class DeleteBusinessSales extends Command
{
    /**
     * The name and signature of the console command.
     *
     * Accepts a business ID as an argument
     */
    protected $signature = 'sales:delete-for-business {business_id}';

    /**
     * The console command description.
     */
    protected $description = 'Deletes all sell and sales_order transactions for a given business ID using deleteSale()';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $business_id = $this->argument('business_id');

        $this->info("🔄 Fetching all sales for business ID: $business_id...");

        $transaction_ids = Transaction::where('business_id', $business_id)
            ->whereIn('type', ['sell', 'sales_order'])
            ->pluck('id');

        if ($transaction_ids->isEmpty()) {
            $this->warn("⚠️  No sales found for business ID: $business_id.");
            return;
        }

        $this->info("✅ Found {$transaction_ids->count()} transactions. Starting deletion...");

        $transactionUtil = app(TransactionUtil::class);

        $failures = [];

        DB::beginTransaction();

        try {
            foreach ($transaction_ids as $transaction_id) {
                $result = $transactionUtil->deleteSale($business_id, $transaction_id);

                if (empty($result['success'])) {
                    $failures[] = $transaction_id;
                    Log::warning("❌ Failed to delete transaction ID: $transaction_id");
                } else {
                    $this->info("✔️  Deleted transaction ID: $transaction_id");
                }
            }

            DB::commit();

            $this->info("🎉 All deletions completed.");

            if (!empty($failures)) {
                $this->warn("⚠️  Some transactions failed to delete:");
                foreach ($failures as $fail_id) {
                    $this->line(" - Transaction ID: $fail_id");
                }
            }

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("🔥 Error deleting sales: " . $e->getMessage());
            $this->error("❌ Error: " . $e->getMessage());
        }
    }
}
